// Fourth mobile QA pass on the beta site (docs/process/qa-mobile-beta-4.md, and its "Section for docs/QA.md"): the
// 2026-10-16 whole-board crawl on the build that carries fix wave 5 (fix-touch-tips, fix-phone-controls,
// fix-phone-text, fix-phone-sizes, fix-pay-at-place, fix-data-3, fix-sec-3). The user, 2026-10-16: "Make sure we
// check for all phone sizes from iPhone mini to razr to duo or something", so these tests use the sizes of
// test/e2e/phone-sizes.mjs.
//
// The beta site is static only, so these tests serve a build (BETA_QA4_DIST, else BETA_QA_DIST, else dist/) under
// /melon-seek/ the way GitHub Pages does, and open /melon-seek/beta/ on an emulated phone (isMobile, hasTouch, the
// size's own DPR and user agent). Every request to another host is aborted, so the map has no basemap (the
// "Basemap unavailable" note is the sandbox's, and the tests look through it). Gestures are real touch:
// page.touchscreen.tap, and CDP Input.dispatchTouchEvent where a drag is needed.
//
// Tests tagged "[M-n]" encode an open bug and fail until it is fixed; the others guard flows that work today.
// BETA_QA4_SHOTS=1 saves each failing case's screenshot to docs/screenshots/qa-mobile-beta-4/.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { ROOT, assert, skip } from './harness.js';
import { ALL_SIZES, contextFor } from './phone-sizes.mjs';
import { unpackJobs } from '../../public/api.js';

const SHOTS = path.join(ROOT, 'docs', 'screenshots', 'qa-mobile-beta-4');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const size = (w, h) => {
  const d = ALL_SIZES.find((s) => s.width === w && s.height === h);
  assert(d, `test/e2e/phone-sizes.mjs lists ${w}x${h}`);
  return d;
};
const BOARDS = ['amazon', 'apple', 'google', 'meta', 'microsoft', 'nvidia', 'netflix'];
const NAMES = { amazon: 'Amazon', apple: 'Apple', google: 'Google', meta: 'Meta', microsoft: 'Microsoft', nvidia: 'NVIDIA', netflix: 'Netflix' };

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.csv': 'text/csv', '.txt': 'text/plain', '.woff2': 'font/woff2' };
const distDir = () => path.resolve(process.env.BETA_QA4_DIST || process.env.BETA_QA_DIST || path.join(ROOT, 'dist'));
let shared = null;
/** Serve the build under /melon-seek/ (gzip, like Pages); null when there is no beta build with the big-tech lists. */
async function serveBeta() {
  if (shared) return shared;
  const dist = distDir();
  if (!fs.existsSync(path.join(dist, 'beta', 'index.html')) || !fs.existsSync(path.join(dist, 'beta', 'api', 'jobs', 'amazon.json'))) return null;
  const server = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    if (!u.pathname.startsWith('/melon-seek/')) { res.writeHead(302, { location: '/melon-seek/' }); return res.end(); }
    let rel;
    try { rel = decodeURIComponent(u.pathname.slice('/melon-seek/'.length)); } catch { res.writeHead(400); return res.end(); }
    let p = path.join(dist, rel);
    if (p !== dist && !p.startsWith(dist + path.sep)) { res.writeHead(403); return res.end(); }
    if (fs.existsSync(p) && fs.statSync(p).isDirectory()) p = path.join(p, 'index.html');
    if (!fs.existsSync(p)) { res.writeHead(404); return res.end(); }
    const type = MIME[path.extname(p)] || 'application/octet-stream';
    const body = fs.readFileSync(p);
    if (/text|javascript|json|svg|csv/.test(type) && /gzip/.test(req.headers['accept-encoding'] || '')) {
      res.writeHead(200, { 'content-type': type, 'content-encoding': 'gzip' });
      return res.end(zlib.gzipSync(body));
    }
    res.writeHead(200, { 'content-type': type });
    res.end(body);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  server.unref();
  const origin = `http://127.0.0.1:${server.address().port}`;
  shared = { origin, base: `${origin}/melon-seek/`, dist };
  return shared;
}

const lists = new Map();
/** A board's postings, unpacked from the build's static list (the same objects the page gets). */
async function boardJobs(st, slug, site = 'beta/') {
  const key = `${site}${slug}`;
  if (!lists.has(key)) {
    const f = path.join(st.dist, site, 'api', 'jobs', `${slug}.json`);
    if (!fs.existsSync(f)) skip(`no ${slug} list in this build`);
    lists.set(key, await unpackJobs(JSON.parse(fs.readFileSync(f, 'utf8'))));
  }
  return lists.get(key);
}

/** A phone page of one size from phone-sizes.mjs on the beta site (or the main site with site: ''). */
async function phone(ctx, d, { hash = 'c=apple', site = 'beta/', colorScheme = 'light', wait = true } = {}) {
  const st = await serveBeta();
  if (!st) skip('no beta build with the big-tech lists (npm run build, or BETA_QA4_DIST=<dir>)');
  const context = await ctx.browser.newContext({ ...contextFor(d), colorScheme });
  ctx.cleanup.push(() => context.close());
  await context.route((u) => u.origin !== st.origin, (r) => r.abort('blockedbyclient'));
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
  const go = async (h, settle = 900) => {
    await page.goto('about:blank');
    await page.goto(`${st.base}${site}${h ? `#${h}` : ''}`);
    await page.waitForFunction(() => { const t = document.querySelector('#resultsTitle'); return t && !/Loading/.test(t.textContent) && /\d|No roles/.test(t.textContent) && (document.querySelector('#resultsList .card[data-id]') || /\b0 roles|No roles/.test(t.textContent)); }, null, { timeout: 90000 });
    await sleep(settle);
  };
  if (wait) await go(hash);
  return { page, errors, go, st, context };
}
async function tapBox(page, b, wait = 450) { await page.touchscreen.tap(b.x + b.width / 2, b.y + b.height / 2); await sleep(wait); }
async function tapSel(page, sel, wait = 450) {
  const b = await page.locator(`${sel} >> visible=true`).first().boundingBox();
  assert(b, `${sel} has no box`);
  await tapBox(page, b, wait);
}
async function shot(page, name) {
  if (!process.env.BETA_QA4_SHOTS) return;
  fs.mkdirSync(SHOTS, { recursive: true });
  try { await page.screenshot({ path: path.join(SHOTS, `${name}.png`), timeout: 15000 }); } catch { /* evidence only */ }
}
const sheetState = (page) => page.evaluate(() => document.body.dataset.sheet);
async function sheetTo(page, s) { for (let i = 0; i < 4 && (await sheetState(page)) !== s; i++) await tapSel(page, '#sheetHandle', 650); }
async function openJob(go, page, id) {
  await go(`c=${String(id).split(':')[0]}&job=${encodeURIComponent(id)}`, 1200);
  await page.waitForSelector('#drawer:not([hidden]) #drawerTitle', { timeout: 30000 });
  await sleep(500);
}
const topPaidId = (page) => page.evaluate(() => document.querySelector('#resultsList .card[data-id]')?.dataset.id);
/** Open a job page on the board already loaded, through the hash (no reload: the whole list stays in the page). */
async function openInPlace(page, id) {
  await page.evaluate((id) => { location.hash = `c=${String(id).split(':')[0]}&job=${encodeURIComponent(id)}`; }, id);
  await page.waitForFunction((id) => !document.querySelector('#drawer').hidden && document.querySelector('#drawerTitle')?.textContent && location.hash.includes(encodeURIComponent(id)), id, { timeout: 30000 });
  await sleep(600);
}
/** "ok", "missing", "off screen …" or "covered by …" for the first visible match of `sel`. */
const onScreen = (page, sel) => page.evaluate((sel) => {
  const e = [...document.querySelectorAll(sel)].find((x) => x.getClientRects().length);
  if (!e) return 'missing';
  const r = e.getBoundingClientRect();
  if (r.left < -1 || r.right > innerWidth + 1 || r.top < -1 || r.bottom > innerHeight + 1) return `off screen [${Math.round(r.left)},${Math.round(r.top)},${Math.round(r.right)},${Math.round(r.bottom)}]`;
  const t = document.elementFromPoint(Math.min(innerWidth - 1, Math.max(0, (r.left + r.right) / 2)), Math.min(innerHeight - 1, Math.max(0, (r.top + r.bottom) / 2)));
  if (t && t !== e && !e.contains(t) && !t.contains(e)) return `covered by ${t.tagName.toLowerCase()}${t.id ? '#' + t.id : ''}.${String(t.className).split(' ')[0]}`;
  return 'ok';
}, sel);

export function registerBetaMobileQa4Tests(suite) {
  /* ------------------------------------------------------------------ guards (pass today) */

  suite.test('Beta mobile QA 4: [guard] Motorola razr cover screen (352x355): the company menu switches boards; the filter sheet\'s ✕ and "Show N roles" are on screen and "Show N roles" equals the result; the job page\'s Back, next and Apply are on screen', async (ctx) => {
    const d = size(352, 355);
    const { page, go, errors } = await phone(ctx, d, { hash: 'c=amazon' });
    const bad = [];
    // Company menu: Apple by a tap.
    await tapSel(page, '#companyMenuBtn', 800);
    const item = page.locator('#popover .company-item').filter({ has: page.locator('.company-item-name', { hasText: /^Apple$/ }) }).first();
    await item.evaluate((e) => e.scrollIntoView({ block: 'center' }));
    await sleep(300);
    await tapBox(page, await item.boundingBox(), 0);
    await page.waitForFunction(() => document.querySelector('#companyMenuBtn .company-name')?.textContent === 'Apple' && /^[\d,]+ roles?$/.test(document.querySelector('#resultsTitle')?.textContent.trim() || ''), null, { timeout: 60000 });
    // Filter sheet: Remote, then Show N roles.
    await tapSel(page, '#filtersToggle', 900);
    for (const [what, sel] of [['✕', '#filtersClose'], ['Show N roles', '#filtersDone']]) { const v = await onScreen(page, sel); if (v !== 'ok') bad.push(`filter sheet ${what}: ${v}`); }
    const rem = page.locator('#filterBody label.check', { hasText: /^\s*Remote/ }).first();
    if (await rem.count()) {
      await rem.evaluate((e) => { const det = e.closest('details'); if (det) det.open = true; e.scrollIntoView({ block: 'center' }); });
      await sleep(300);
      await tapBox(page, await rem.boundingBox(), 900);
    }
    const want = ((await page.textContent('#filtersDone')).match(/[\d,]+/) || [''])[0];
    await tapSel(page, '#filtersDone', 1200);
    const title = await page.textContent('#resultsTitle');
    if (!want || !title.startsWith(`${want} role`)) bad.push(`"Show ${want} roles" vs the result "${title}"`);
    // Job page.
    await go('c=apple', 600);
    await openJob(go, page, await topPaidId(page));
    for (const [what, sel] of [['Back', '#drawerClose'], ['next', '#drawerNext'], ['Apply', '#drawer .drawer-foot a[href^="http"], #drawer a.btn[href^="http"]']]) { const v = await onScreen(page, sel); if (v !== 'ok') bad.push(`job page ${what}: ${v}`); }
    await tapSel(page, '#drawerClose', 900);
    if (await page.evaluate(() => !document.querySelector('#drawer').hidden)) bad.push('Back did not close the job page');
    if (bad.length) await shot(page, 'e2e-guard-razr-cover');
    assert(!bad.length && !errors.length, [...bad, ...errors].join('\n  '));
  });

  suite.test('Beta mobile QA 4: [guard] map Remote on every big-tech board (390x844) and on the Razr cover and the folded Fold: a tap gives "Remote (N)" and N roles', async (ctx) => {
    const bad = [];
    for (const [d, boards] of [[size(390, 844), BOARDS], [size(352, 355), ['amazon', 'netflix']], [size(280, 653), ['apple']]]) {
      const { page, go } = await phone(ctx, d, { hash: `c=${boards[0]}&m=map`, wait: false });
      for (const slug of boards) {
        await go(`c=${slug}&m=map`, 300);
        await page.waitForSelector('#mapHost .ms-pin', { timeout: 30000 });
        await sleep(900);
        const r = page.locator('#mapHost .ms-remote >> visible=true').first();
        if (!(await r.count())) { bad.push(`${slug} ${d.width}x${d.height}: no Remote control`); continue; }
        const n = Number(((await r.innerText()).match(/([\d,]+)/) || ['', ''])[1].replace(/,/g, ''));
        await tapBox(page, await r.boundingBox(), 1200);
        const s = await page.evaluate(() => ({ chip: [...document.querySelectorAll('.area-chip')].map((e) => e.innerText.trim()).filter(Boolean)[0] || '', title: document.querySelector('#resultsTitle').textContent }));
        if (!(s.chip.startsWith('Remote') && s.chip.includes(`(${n})`) && s.title.replace(/,/g, '').startsWith(`${n} role`))) bad.push(`${slug} ${d.width}x${d.height}: control says ${n}, chip "${s.chip}", title "${s.title}"`);
      }
    }
    assert(!bad.length, bad.join('\n  '));
  });

  /* ------------------------------------------------------------------ open bugs (fail today) */

  suite.test('Beta mobile QA 4: [M-48] a card\'s "N places" / "2 levels" line is at least 12 px on a phone (Amazon, NVIDIA, Microsoft; 390x844 and 280x653)', async (ctx) => {
    const st = await serveBeta();
    if (!st) skip('no beta build');
    const bad = [];
    for (const d of [size(390, 844), size(280, 653)]) {
      const { page, go } = await phone(ctx, d, { hash: 'c=amazon', wait: false });
      for (const slug of ['amazon', 'nvidia', 'microsoft']) {
        const j = (await boardJobs(st, slug)).find((x) => (x.salary?.ranges?.length >= 2 || x.salary?.levels?.length >= 2) && x.salary.currency === 'USD');
        if (!j) continue;
        await go(`c=${slug}&q=${encodeURIComponent(j.title)}`, 800);
        await sheetTo(page, 'full');
        const s = await page.evaluate((id) => { const e = document.querySelector(`#resultsList .card[data-id="${CSS.escape(id)}"] .sal-sub`); return e ? { text: e.textContent.trim(), fs: parseFloat(getComputedStyle(e).fontSize) } : null; }, j.id);
        if (!s) { bad.push(`${slug} ${d.width}: no "places"/"levels" line on ${j.id}`); continue; }
        if (s.fs < 12) { bad.push(`${slug} ${d.width}x${d.height}: "${s.text}" is ${s.fs} px`); await shot(page, `e2e-M-48-sal-sub-${slug}-${d.width}`); }
      }
    }
    assert(!bad.length, `text under 12 px:\n  ${bad.join('\n  ')}`);
  });

  suite.test('Beta mobile QA 4: [M-49] the job page\'s Apply label fits one line from 360 px up (two below), so the footer stays one button high (top roles: Microsoft at 390, Amazon and Microsoft at 375, Apple and Netflix at 360, Apple at 280)', async (ctx) => {
    const bad = [];
    for (const [d, boards] of [[size(390, 844), ['microsoft']], [size(375, 812), ['amazon', 'microsoft']], [size(360, 740), ['apple', 'netflix']], [size(280, 653), ['apple']]]) {
      const max = d.width < 360 ? 2 : 1;
      const { page, go } = await phone(ctx, d, { hash: `c=${boards[0]}`, wait: false });
      for (const slug of boards) {
        await go(`c=${slug}`, 300);
        await openInPlace(page, await topPaidId(page));
        const r = await page.evaluate(() => {
          const lab = document.querySelector('#drawer .apply-label');
          if (!lab) return null;
          // The label's own words, without the host line under them.
          const range = document.createRange();
          const first = lab.firstChild;
          range.setStart(first, 0); range.setEnd(first, first.textContent.length);
          const mids = [];
          for (const x of range.getClientRects()) { if (x.width < 0.5) continue; const m = x.top + x.height / 2; if (!mids.some((t) => Math.abs(t - m) < 5)) mids.push(m); }
          const foot = lab.closest('a').parentElement.getBoundingClientRect();
          return { text: first.textContent.trim(), lines: mids.length, foot: Math.round(foot.height) };
        });
        if (!r) { bad.push(`${slug} ${d.width}: no Apply label`); continue; }
        if (r.lines > max) { bad.push(`${slug} ${d.width}x${d.height}: "${r.text}" takes ${r.lines} lines (footer ${r.foot} px)`); await shot(page, `e2e-M-49-apply-${slug}-${d.width}`); }
      }
    }
    assert(!bad.length, `${bad.length} Apply label(s) wrap:\n  ${bad.join('\n  ')}`);
  });

  suite.test('Beta mobile QA 4: [M-50] on the map\'s first view every price pin can be tapped: none sits under the map\'s own legend or Remote control (320x568, 280x653, the Razr cover 352x355)', async (ctx) => {
    const bad = [];
    for (const [d, boards] of [[size(320, 568), ['apple', 'meta', 'netflix']], [size(280, 653), ['apple', 'meta']], [size(352, 355), ['amazon', 'google', 'microsoft']]]) {
      const { page, go } = await phone(ctx, d, { hash: `c=${boards[0]}&m=map`, wait: false });
      for (const slug of boards) {
        await go(`c=${slug}&m=map`, 300);
        await page.waitForSelector('#mapHost .ms-pin', { timeout: 30000 });
        await sleep(1500);
        const hidden = await page.evaluate(() => {
          const m = document.querySelector('#mapHost').getBoundingClientRect();
          const sheet = document.querySelector('#results').getBoundingClientRect();
          const bottom = Math.min(m.bottom, sheet.top, innerHeight);
          const out = [];
          for (const p of document.querySelectorAll('#mapHost .ms-pin')) {
            const b = (p.querySelector('.ms-pin__price, .ms-pin__count') || p).getBoundingClientRect();
            if (!b.width || b.top >= bottom || b.bottom <= m.top) continue;
            // The sandbox has no basemap, so look through its "Basemap unavailable" note (real phones don't show it).
            const reach = [0.15, 0.5, 0.85].some((fx) => { const x = b.left + b.width * fx, y = b.top + b.height / 2; if (x < 0 || x >= innerWidth || y >= bottom) return false; const t = document.elementsFromPoint(x, y).find((e) => !e.closest('.ms-map__offline-note')); return t && (t === p || p.contains(t)); });
            if (!reach) { const t = document.elementsFromPoint(b.left + b.width / 2, b.top + b.height / 2).find((e) => !e.closest('.ms-map__offline-note')); out.push(`"${p.innerText.replace(/\s+/g, ' ').trim().slice(0, 40)}" under ${t ? `${t.tagName.toLowerCase()}.${String(t.className).split(' ')[0]}` : '?'}`); }
          }
          return out;
        });
        if (hidden.length) { bad.push(`${slug} ${d.width}x${d.height}: ${hidden.join('; ')}`); await shot(page, `e2e-M-50-map-pins-${slug}-${d.width}x${d.height}`); }
      }
    }
    assert(!bad.length, `price pins that no tap can reach on the first map view:\n  ${bad.join('\n  ')}`);
  });

  suite.test('Beta mobile QA 4: [M-52] touch phones wider than 860 px (iPhone 15 Pro Max landscape 932x430, Razr inner landscape 1005x412, Surface Duo spanned 1114x720) get 44 px controls and 16 px fields', async (ctx) => {
    const IOS18 = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1';
    // The iPhone Pro Max in landscape is not in phone-sizes.mjs; it is the iPhone most likely to be over 860 px.
    const devices = [{ name: 'iPhone 15 Pro Max (landscape)', width: 932, height: 430, dpr: 3, ua: IOS18, platform: 'ios' }, size(1005, 412), size(1114, 720)];
    const bad = [];
    for (const d of devices) {
      const { page, go } = await phone(ctx, d, { hash: 'c=apple' });
      const ctl = await page.evaluate(() => {
        const out = [];
        for (const [name, sel] of [['company menu', '#companyMenuBtn'], ['search', '#search'], ['view switch', '.topbar .seg button'], ['data badge', '#dataBadge'], ['theme', '#themeBtn'], ['Filters', '#filtersToggle'], ['quick chip', '#quickChips > *'], ['sort', '#sortBy'], ['Clusters/Ranges', '#vizControls button']]) {
          const e = [...document.querySelectorAll(sel)].find((x) => x.getClientRects().length);
          if (!e) continue;
          const r = e.getBoundingClientRect();
          const fs = e.matches('input, select') ? parseFloat(getComputedStyle(e).fontSize) : null;
          if (Math.min(r.width, r.height) < 43.5) out.push(`${name} ${Math.round(r.width)}x${Math.round(r.height)}`);
          if (fs !== null && fs < 16) out.push(`${name} font ${fs} px`);
        }
        return out;
      });
      await go('c=apple&m=insights', 600);
      await page.waitForSelector('#compHost input', { timeout: 60000 });
      await sleep(600);
      const fields = await page.evaluate(() => [...document.querySelectorAll('#compHost input, #insightsHost select')].filter((e) => e.getClientRects().length && !/checkbox|radio|hidden|range/.test(e.type)).map((e) => parseFloat(getComputedStyle(e).fontSize)).filter((f) => f < 16));
      if (fields.length) ctl.push(`${fields.length} Insights field(s) at ${[...new Set(fields)].join('/')} px`);
      if (ctl.length) { bad.push(`${d.name} ${d.width}x${d.height}: ${ctl.join(', ')}`); await shot(page, `e2e-M-52-wide-touch-${d.width}x${d.height}`); }
    }
    assert(!bad.length, `mouse-sized controls on a touch phone (iOS zooms the page into any field under 16 px):\n  ${bad.join('\n  ')}`);
  });

  suite.test('Beta mobile QA 4: [M-51] the job page\'s meta line never starts or ends a line with "·" (Amazon and Meta top roles, 390 and 360)', async (ctx) => {
    const bad = [];
    for (const d of [size(390, 844), size(360, 740)]) {
      const { page, go } = await phone(ctx, d, { hash: 'c=amazon', wait: false });
      for (const slug of ['amazon', 'meta']) {
        await go(`c=${slug}`, 300);
        await openInPlace(page, await topPaidId(page));
        for (let k = 0; k < 8; k++) {
          if (k) {
            const pos = await page.textContent('#drawerPos');
            await tapSel(page, '#drawerNext', 300);
            await page.waitForFunction((p) => document.querySelector('#drawerPos')?.textContent !== p, pos, { timeout: 15000 });
            await sleep(400);
          }
          const id = await page.evaluate(() => decodeURIComponent((location.hash.match(/job=([^&]+)/) || ['', ''])[1]));
          const r = await page.evaluate(() => {
            for (const s of document.querySelectorAll('#drawer .d-meta .sep')) {
              let n = s.nextElementSibling; while (n && !n.getClientRects().length) n = n.nextElementSibling;
              let p = s.previousElementSibling; while (p && !p.getClientRects().length) p = p.previousElementSibling;
              if (!n || !p || !s.getClientRects().length) continue;
              const sr = s.getBoundingClientRect(), mid = sr.top + sr.height / 2;
              const nr = n.getClientRects()[0], pr = [...p.getClientRects()].pop();
              if (Math.abs(nr.top + nr.height / 2 - mid) > 6 || Math.abs(pr.top + pr.height / 2 - mid) > 6) return s.parentElement.innerText.replace(/\s+/g, ' ').trim();
            }
            return null;
          });
          if (r) { bad.push(`${id} ${d.width}: "${r}"`); if (bad.length <= 2) await shot(page, `e2e-M-51-meta-sep-${slug}-${d.width}`); }
        }
      }
    }
    assert(!bad.length, `a "·" left at a line's end or start:\n  ${bad.join('\n  ')}`);
  });
}
